package fibonacciMain;

import es.iessoterhernandez.daw.endes.Fibonacci;

public class FibonacciMain {

	public static void main(String[] args) {
		
		Fibonacci f = new Fibonacci();
		f.setNombre("Serie de Fibonacci");
		f.setTamanio(10);
		f.mostrarSerie();

	}

}
