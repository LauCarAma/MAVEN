package es.iessoterhernandez.daw.endes;

import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;


public class HelloWorldPdf {

	
	public static final String PDF_ROUTE = "pdf_final/hello_world.pdf";
	
	        public static void main(String args[]) throws IOException {
	            File file = new File(PDF_ROUTE);
	            file.getParentFile().mkdirs();
	            new HelloWorldPdf().createPdf(PDF_ROUTE);
	        }

	        public void createPdf(String location) throws IOException {
	        	FileOutputStream fos = new FileOutputStream(location);
	            PdfWriter writer = new PdfWriter(fos);
	            PdfDocument pdf = new PdfDocument(writer);
	            Document document = new Document(pdf);
	            document.add(new Paragraph("Hello World!"));
	            document.close();
	        }
	}

